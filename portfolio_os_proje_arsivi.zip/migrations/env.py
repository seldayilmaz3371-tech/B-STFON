import sys
from pathlib import Path
from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context

# DÜZELTME (bu turda — Alembic kurulumu): proje kökü sys.path'e
# eklenmeli, aksi halde `from src...` import'ları migrations/ altından
# çalıştırıldığında BAŞARISIZ olur (Alembic, env.py'ı migrations/
# klasöründen çalıştırıyor, proje kökünden DEĞİL).
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# DÜZELTME: target_metadata artık PROJENİN GERÇEK metadata nesnesine
# bağlı (orm_models.py) — autogenerate bu sayede GERÇEK şema ile
# karşılaştırma yapabiliyor. Daha önce None idi (autogenerate hiçbir
# şey ÜRETEMEZDİ).
from src.infrastructure.database.orm_models import metadata as target_metadata  # noqa: E402

# DÜZELTME: Veritabanı URL'i artık settings.py'dan (config-driven
# yapı prensibiyle TUTARLI — alembic.ini'de HARDCODE edilmiş bir URL
# yerine) okunuyor. Eğer ortam değişkeni/config'te bir URL varsa onu
# kullan, yoksa alembic.ini'deki sqlalchemy.url'e (varsayılan/test
# amaçlı) düş.
try:
    from src.infrastructure.config.settings import get_settings
    config.set_main_option("sqlalchemy.url", get_settings().database.url)
except Exception:  # noqa: BLE001 — settings okunamazsa alembic.ini'deki varsayılana düş
    pass


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection, target_metadata=target_metadata
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
